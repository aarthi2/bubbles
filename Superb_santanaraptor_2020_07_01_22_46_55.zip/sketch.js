var bubbles = [];

function setup() {
  createCanvas(600,400);
  
  bubble1 = new Bubble();
  bubble2 = new Bubble();
  bubble3 = new Bubble();
  bubble3 = new Bubble();
  bubble4 = new Bubble();
  bubble5 = new Bubble();
  bubble6 = new Bubble();
  bubble7 = new Bubble();
  bubble8 = new Bubble();
  bubble9 = new Bubble();
  bubble10 = new Bubble();

}

function draw() {
  background(color="pink");
  bubble1.move();
  bubble2.move();
  bubble3.move();
  bubble4.move();
  bubble5.move();
  bubble6.move();
  bubble7.move();
  bubble8.move();
  bubble9.move();
  bubble10.move();


  
  bubble1.display();
  bubble2.display();
  bubble3.display();
  bubble4.display();
  bubble5.display();
  bubble6.display();
  bubble7.display();
  bubble8.display();
  bubble9.display();
  bubble10.display();

}

    